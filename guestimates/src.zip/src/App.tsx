import React, { useState } from 'react';
import { Container, Table, TableBody, TableCell, TableHead, TableRow, Button } from '@mui/material';
import TaskRow from './components/TaskRow';
import ConfigModal from './components/ConfigModal';
import { Task, TaskTypeConfig, defaultTaskTypeConfig } from './interfaces/Task';
import ExportCSV from './components/ExportCSV';
import ImportExcel from './components/ImportCSV';
import './App.css';

const App: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [taskTypeConfig, setTaskTypeConfig] = useState<TaskTypeConfig>(defaultTaskTypeConfig);
  const [isConfigOpen, setIsConfigOpen] = useState(false);

  const addTask = () => {
    setTasks([...tasks, { name: '', feType: {effort: 'small'}, beType: {effort: 'small'}, analysisType: {effort: 'small'}, documentationType: {effort: 'small'}, certificationType: {effort: 'small'} }]);
  };

  const updateTask = (index: number, updatedTask: Task) => {
    debugger
    const updatedTasks = tasks.map((task, i) => (i === index ? updatedTask : task));
    setTasks(updatedTasks);
  };

  const calculateTotalHours = () => {
    return tasks.reduce((total, task) => {
      const taskTotal = taskTypeConfig[task.feType.effort] +
                        taskTypeConfig[task.beType.effort] +
                        taskTypeConfig[task.analysisType.effort] +
                        taskTypeConfig[task.documentationType.effort] +
                        taskTypeConfig[task.certificationType.effort];
      return total + taskTotal;
    }, 0);
  };

  const handleImport = (importedTasks: Task[], importedConfig: TaskTypeConfig) => {
    setTasks(importedTasks);
    setTaskTypeConfig(importedConfig);
  };

  return (
    <Container>
      <h1>Guestimates</h1>
      
      <div className='header-buttons'>
        <Button variant="contained" onClick={() => setIsConfigOpen(true)}>Configurar tempos de tarefa</Button>
        <div className='import-feature-buttons'>
          <ExportCSV config={taskTypeConfig} tasks={tasks}/>
          <ImportExcel onImport={handleImport}/>
        </div>
      </div>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Tarefa</TableCell>
            <TableCell>FE Dev</TableCell>
            <TableCell>BE Dev</TableCell>
            <TableCell>Análise</TableCell>
            <TableCell>Documentação</TableCell>
            <TableCell>Certificação</TableCell>
            <TableCell>Total Horas</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {tasks.map((task, index) => (
            <TaskRow key={index} index={index} task={task} taskTypeConfig={taskTypeConfig} updateTask={updateTask} />
          ))}
          <TableRow>
            <TableCell colSpan={6}>Total de horas de todas as tarefas</TableCell>
            <TableCell>{calculateTotalHours()}</TableCell>
          </TableRow>
        </TableBody>
      </Table>
      <Button variant="contained" onClick={addTask}>Add Task</Button>
      <ConfigModal isOpen={isConfigOpen} taskTypeConfig={taskTypeConfig} setTaskTypeConfig={setTaskTypeConfig} onClose={() => setIsConfigOpen(false)} />
        
    </Container>
  );
};

export default App;
